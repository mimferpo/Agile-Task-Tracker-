### Story 1: Create user login page

**As a** user  
**I need** to be able to log in securely  
**So that** I can access personalized features

**Acceptance Criteria**
- [ ] Given I’m on the login page  
- [ ] When I enter valid credentials  
- [ ] Then I should be redirected to my dashboard

**Estimate**: 3  
**Labels**: product backlog
