### Story 10: Remove deprecated API calls

**As a** developer  
**I need** to replace old API calls  
**So that** the app remains compatible and secure

**Acceptance Criteria**
- [ ] Given old API usage  
- [ ] When I update to the new API  
- [ ] Then all functionalities should continue to work

**Estimate**: 3  
**Labels**: technical debt
