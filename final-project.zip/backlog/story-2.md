### Story 2: View dashboard

**As a** logged-in user  
**I need** to view my dashboard  
**So that** I can access my tools

**Acceptance Criteria**
- [ ] Given I’m logged in  
- [ ] When I navigate to the dashboard  
- [ ] Then I see my user-specific content

**Estimate**: 2  
**Labels**: sprint backlog
