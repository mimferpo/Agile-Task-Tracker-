### Story 9: Refactor authentication logic

**As a** developer  
**I need** to clean up the login module  
**So that** the codebase is easier to maintain

**Acceptance Criteria**
- [ ] Given the current login logic  
- [ ] When I refactor the code  
- [ ] Then the login functionality should remain the same

**Estimate**: 2  
**Labels**: technical debt
