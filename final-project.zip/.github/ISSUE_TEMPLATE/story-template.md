---
name: User Story
about: Describe a new user story
title: "[Story] "
labels: user story
assignees: ''
---

**User Story**  
As a [type of user], I need [some feature] so that [some benefit].

**Acceptance Criteria**  
- [ ] Given [context]  
- [ ] When [action]  
- [ ] Then [expected result]

**Estimate**: [1, 2, 3, 5, 8]

**Labels**: user story, sprint backlog, technical debt (if applicable)
