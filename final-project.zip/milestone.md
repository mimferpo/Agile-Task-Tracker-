## Sprint Title: Sprint 1 – MVP Setup

### Duration
Start: 2025-06-01  
End: 2025-06-07

### Goal
Deliver a functional MVP skeleton with routing and core user story handling.
