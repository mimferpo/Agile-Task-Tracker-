# Final Agile Project

This repository includes the required files for the Agile project peer-reviewed assignment:
- Kanban board link
- User stories
- Milestone
- Burndown chart
